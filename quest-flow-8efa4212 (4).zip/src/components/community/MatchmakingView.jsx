import React, { useState, useEffect, useCallback } from 'react';
import { User, UserSwipe, Match, Guild, GuildMembership } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Loader2, Heart, X, RefreshCw, UserSearch } from 'lucide-react';
import ProfileCard from './ProfileCard';
import ItsAMatchModal from './ItsAMatchModal';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MatchmakingView() {
  const [profiles, setProfiles] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [match, setMatch] = useState(null);
  const navigate = useNavigate();

  const loadProfiles = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Step 1: Get current user
      let me;
      try {
        me = await User.me();
        setCurrentUser(me);
      } catch (userError) {
        console.error("Failed to get current user:", userError);
        setError("Please log in to use the team matching feature.");
        setIsLoading(false);
        return;
      }

      // Step 2: Get all users
      let allUsers;
      try {
        allUsers = await User.list();
        if (!allUsers || allUsers.length === 0) {
          setError("No other users found in the platform yet. Check back later!");
          setIsLoading(false);
          return;
        }
      } catch (usersError) {
        console.error("Failed to get user list:", usersError);
        setError("Unable to load user profiles. Please try again later.");
        setIsLoading(false);
        return;
      }

      // Step 3: Get user's previous swipes
      let mySwipes = [];
      try {
        mySwipes = await UserSwipe.filter({ swiper_email: me.email });
      } catch (swipeError) {
        console.warn("Failed to load swipe history, continuing without it:", swipeError);
        // Continue without swipe history - user will see all profiles
      }

      const swipedEmails = new Set(mySwipes.map(swipe => swipe.swiped_email));
      
      // Step 4: Filter profiles
      const filteredProfiles = allUsers.filter(user => {
        // Exclude current user
        if (user.email === me.email) return false;
        
        // Exclude users they've already swiped on
        if (swipedEmails.has(user.email)) return false;
        
        // Only include active users
        if (user.account_status && user.account_status !== 'active') return false;
        
        return true;
      });

      setProfiles(filteredProfiles);
      setCurrentIndex(0);

      if (filteredProfiles.length === 0) {
        setError("You've seen all available profiles! Check back later for new users.");
      }

    } catch (err) {
      console.error("Unexpected error in loadProfiles:", err);
      setError("An unexpected error occurred. Please refresh the page and try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProfiles();
  }, [loadProfiles]);

  const handleSwipe = async (swipedProfile, status) => {
    if (!currentUser) return;

    try {
      // Create the swipe record
      await UserSwipe.create({
        swiper_email: currentUser.email,
        swiped_email: swipedProfile.email,
        status: status,
      });
      
      // If it was a 'like', check for a match
      if (status === 'liked') {
        try {
          const theirSwipe = await UserSwipe.filter({
            swiper_email: swipedProfile.email,
            swiped_email: currentUser.email,
            status: 'liked',
          });

          if (theirSwipe.length > 0) {
            // It's a match!
            await Match.create({
                user_emails: [currentUser.email, swipedProfile.email]
            });
            setMatch({ user1: currentUser, user2: swipedProfile });
          }
        } catch (matchError) {
          console.error("Error checking for match:", matchError);
          // Continue even if match check fails
        }
      }
      
      // Move to the next card
      setCurrentIndex(prev => prev + 1);
      
    } catch (swipeError) {
      console.error("Error creating swipe:", swipeError);
      alert("Failed to record your choice. Please try again.");
    }
  };
  
  const handleCreateParty = async (user1, user2) => {
    if (!user1 || !user2) return;
    
    try {
        const partyName = `Party: ${user1.full_name?.split(' ')[0] || user1.email.split('@')[0]} & ${user2.full_name?.split(' ')[0] || user2.email.split('@')[0]}`;
        const newParty = await Guild.create({
            name: partyName,
            description: `A private party for collaboration between ${user1.full_name || user1.email} and ${user2.full_name || user2.email}.`,
            is_party: true,
            is_public: false,
            guild_type: 'custom'
        });

        await Promise.all([
          GuildMembership.create({ guild_id: newParty.id, user_email: user1.email, role: 'owner' }),
          GuildMembership.create({ guild_id: newParty.id, user_email: user2.email, role: 'owner' })
        ]);

        setMatch(null);
        navigate(createPageUrl(`GuildDetail?id=${newParty.id}`));

    } catch (err) {
        console.error("Failed to create party:", err);
        alert("There was an error creating your party. Please try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-gray-500 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading profiles...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 creator-card max-w-lg mx-auto">
        <UserSearch className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Unable to Load Profiles</h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
        <Button onClick={loadProfiles} className="creator-btn">
          <RefreshCw className="w-4 h-4 mr-2" />
          Try Again
        </Button>
      </div>
    );
  }

  const currentProfile = profiles[currentIndex];
  const hasMoreProfiles = currentIndex < profiles.length;

  return (
    <>
      <div className="max-w-md mx-auto relative h-[600px] flex items-center justify-center">
        {hasMoreProfiles && currentProfile ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={currentProfile.id}
              className="absolute w-full h-full"
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{
                x: Math.random() > 0.5 ? 300 : -300,
                opacity: 0,
                scale: 0.8,
                transition: { duration: 0.3 }
              }}
              transition={{ type: 'spring', stiffness: 100, damping: 20 }}
            >
              <ProfileCard
                profile={currentProfile}
                onLike={() => handleSwipe(currentProfile, 'liked')}
                onPass={() => handleSwipe(currentProfile, 'passed')}
                isTopCard={true}
              />
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="text-center p-8 creator-card">
            <UserSearch className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">All Caught Up!</h3>
            <p className="text-gray-600 dark:text-gray-400 mt-2">You've seen all available profiles. Check back later for new users!</p>
            <Button onClick={loadProfiles} className="mt-4 creator-btn">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        )}
      </div>

      {match && (
        <ItsAMatchModal
          user1={match.user1}
          user2={match.user2}
          onClose={() => setMatch(null)}
          onStartParty={() => handleCreateParty(match.user1, match.user2)}
        />
      )}
    </>
  );
}