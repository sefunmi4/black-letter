import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Heart, X, Github, Briefcase, Code, User } from 'lucide-react';
import { motion } from 'framer-motion';

const roleTypeColors = {
  creator: "bg-purple-100 text-purple-700 dark:bg-purple-900/50 dark:text-purple-300",
  developer: "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300",
  freelancer: "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300",
  explorer: "bg-orange-100 text-orange-700 dark:bg-orange-900/50 dark:text-orange-300",
};

export default function ProfileCard({ profile, onLike, onPass, isTopCard }) {
  if (!profile) return null;

  const userType = profile.user_type || 'explorer';
  const displayName = profile.full_name || profile.email?.split('@')[0] || 'Unknown User';

  return (
    <Card className="creator-card w-full h-full overflow-hidden flex flex-col shadow-2xl">
      <div className="relative h-64 bg-gray-200 dark:bg-gray-700">
        {profile.github_avatar_url ? (
          <img
            src={profile.github_avatar_url}
            alt={displayName}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.nextSibling.style.display = 'flex';
            }}
          />
        ) : null}
        <div className={`w-full h-full flex items-center justify-center text-gray-400 ${profile.github_avatar_url ? 'hidden' : ''}`}>
          <User className="w-24 h-24" />
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <h2 className="text-2xl font-bold text-white">{displayName}</h2>
          {profile.title && <p className="text-white/90 text-sm">{profile.title}</p>}
        </div>
      </div>
      <CardContent className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <Badge className={`${roleTypeColors[userType]} mb-3 capitalize text-sm py-1 px-3`}>
            {userType}
          </Badge>
          <p className="text-gray-700 dark:text-gray-300 text-sm line-clamp-3 mb-4">
            {profile.bio || "This user hasn't written a bio yet."}
          </p>
          {profile.skills && profile.skills.length > 0 && (
            <div className="space-y-2 mb-4">
                <h4 className="text-sm font-semibold flex items-center gap-2"><Code className="w-4 h-4" /> Skills</h4>
                <div className="flex flex-wrap gap-1">
                {profile.skills.slice(0, 5).map(skill => (
                    <Badge key={skill} variant="secondary" className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                    {skill}
                    </Badge>
                ))}
                </div>
            </div>
          )}
        </div>
        <div className="flex items-center justify-center gap-4 mt-4">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onPass}
            disabled={!isTopCard}
            className="w-16 h-16 rounded-full bg-white dark:bg-gray-700/50 border-2 border-red-200 dark:border-red-800 flex items-center justify-center text-red-500 shadow-lg disabled:opacity-50"
          >
            <X className="w-8 h-8" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onLike}
            disabled={!isTopCard}
            className="w-20 h-20 rounded-full bg-white dark:bg-gray-700/50 border-2 border-green-200 dark:border-green-800 flex items-center justify-center text-green-500 shadow-xl disabled:opacity-50"
          >
            <Heart className="w-10 h-10" />
          </motion.button>
        </div>
      </CardContent>
    </Card>
  );
}