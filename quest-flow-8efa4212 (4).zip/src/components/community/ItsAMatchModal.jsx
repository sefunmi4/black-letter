import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Heart, MessageSquare, X } from 'lucide-react';

const Avatar = ({ user }) => (
  <div className="relative">
    <img
      src={user.github_avatar_url || `https://ui-avatars.com/api/?name=${user.full_name}&background=random`}
      alt={user.full_name}
      className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-white shadow-lg"
    />
  </div>
);

export default function ItsAMatchModal({ user1, user2, onClose, onStartParty }) {
  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.7, opacity: 0 }}
          transition={{ type: 'spring', damping: 15, stiffness: 200 }}
          className="relative w-full max-w-lg bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl p-6 text-center text-white"
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white">
            <X className="w-6 h-6" />
          </button>
          
          <motion.h2 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
            className="text-4xl md:text-5xl font-bold font-serif"
          >
            It's a Match!
          </motion.h2>

          <p className="mt-2 text-white/80">
            You and {user2.full_name} have liked each other.
          </p>

          <div className="flex justify-center items-center my-8 gap-4">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1, transition: { delay: 0.3 } }}
            >
              <Avatar user={user1} />
            </motion.div>
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1, transition: { delay: 0.5, type: 'spring' } }}
            >
              <Heart className="w-12 h-12 text-pink-300" />
            </motion.div>
            <motion.div
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1, transition: { delay: 0.3 } }}
            >
              <Avatar user={user2} />
            </motion.div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={onStartParty}
              className="w-full h-14 text-lg bg-white text-purple-600 hover:bg-gray-100"
            >
              <MessageSquare className="w-5 h-5 mr-2" />
              Start a Party
            </Button>
            <Button
              onClick={onClose}
              variant="link"
              className="w-full text-white/80 hover:text-white"
            >
              Keep Swiping
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}